package com.blueyonder.helloworldservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloworldServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
